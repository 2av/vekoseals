<?php $title = 'Contact Us - Vako Seals Pvt. Ltd.'; ?>
<?php $description = 'Contact Vako Seals - Get in touch with our offices across India'; ?>

<section class="hero">
        <h1>Contact Us</h1>
        <p>Get in touch with our offices across India</p>
    </section>

    <section class="content-section">
        <h2>Our Addresses</h2>
        
        <div class="contact-grid">
            <div class="contact-card">
                <h3>Vako Seals Pvt. Ltd.</h3>
                <p>P.O. Box No. 9063,<br>
                K. R. D. N. Trust Estate,<br>
                Near Pravasi Indl. Estate,<br>
                Off Aarey Road,<br>
                Goregoan (East),<br>
                Mumbai - 400 063, India.</p>
                <p><strong>Phone:</strong> 91-22-2927 1960 / 91-22-4037 1234<br>
                91-22-2927 1933 / 91-22-2927 1921</p>
                <p><strong>Fax:</strong> 91-22-2927 0618</p>
                <p><strong>Email:</strong> <a href="mailto:vako@vakoseals.com">vako@vakoseals.com</a></p>
            </div>

            <div class="contact-card">
                <h3>Vako Seals Pvt. Ltd. - Unit 2</h3>
                <p>Gala No.6/9,<br>
                Sadanand Raut Industrial Estate,<br>
                Chinch Pada : 401 208,<br>
                Vasai (E)<br>
                Thane, India.</p>
                <p><strong>Phone:</strong> 91-250-245 0690, 250-6520598<br>
                91-250-245 0702</p>
                <p><strong>Fax:</strong> 91-250 245 0057</p>
                <p><strong>Email:</strong> <a href="mailto:unit2@vakoseals.com">unit2@vakoseals.com</a></p>
            </div>

            <div class="contact-card">
                <h3>Vako Seals Pvt. Ltd. - Unit 3</h3>
                <p>Plot No. 3,<br>
                Agarwal Udyog Nagar,<br>
                Waliv, Vasai (E)<br>
                Thane 401 208, India.</p>
                <p><strong>Phone:</strong> 91-250-245 6022, 250-3299929</p>
                <p><strong>Email:</strong> <a href="mailto:unit3@vakoseals.com">unit3@vakoseals.com</a></p>
            </div>
        </div>

        <h2>Branch Offices</h2>
        
        <div class="contact-grid">
            <div class="contact-card">
                <h3>Coimbatore</h3>
                <p>Mr. B. Muralidharan<br>
                M/s. Vako Seals Pvt.Ltd.,<br>
                Sun Rise Aptt., Gr. Floor,<br>
                Door No. 72-A<br>
                Arunachalam Road (West)<br>
                R.S.Puram<br>
                Coimbatore : 641 002.</p>
                <p><strong>Phone:</strong> 91-422 247 3125 / 3135<br>
                91-9894339486</p>
                <p><strong>Email:</strong> <a href="mailto:muralidharan@vakoseals.com">muralidharan@vakoseals.com</a></p>
            </div>

            <div class="contact-card">
                <h3>New Delhi</h3>
                <p>Mr. N. K. Garg,<br>
                M/s. Vako Seals Pvt.Ltd.,<br>
                C-543, Saraswati Vihar,<br>
                New Delhi : 110 034.</p>
                <p><strong>Phone:</strong> 91-11 2735 1687<br>
                91-11 4725 7787</p>
                <p><strong>Email:</strong> <a href="mailto:nkgarg@vakoseals.com">nkgarg@vakoseals.com</a></p>
            </div>

            <div class="contact-card">
                <h3>Bangalore</h3>
                <p>Mr. K. Mohandasan<br>
                M/s. Vako Seals Pvt.Ltd.,<br>
                A2G4, Saroj Blue Bells,<br>
                ECC Road,<br>
                Pattandur Agrahara,<br>
                Whitefield,<br>
                Bangalore: 560 066.</p>
                <p><strong>Phone:</strong> 91-9092488242</p>
                <p><strong>Email:</strong> <a href="mailto:mohandasan@vakoseals.com">mohandasan@vakoseals.com</a></p>
            </div>

            <div class="contact-card">
                <h3>Hyderabad</h3>
                <p>Mr. D.Kanni Sekhar<br>
                M/s. Vako Seals Pvt. Ltd.,<br>
                H.NO:16-89<br>
                Sai Nagar Colony Alwal,<br>
                Secunderabad : 500 015.</p>
                <p><strong>Phone:</strong> 91-40 713 3530</p>
                <p><strong>Email:</strong> <a href="mailto:dksekhar2010@gmail.com">dksekhar2010@gmail.com</a></p>
            </div>
        </div>

        <div class="image-gallery" style="margin: 2rem 0; max-width: 600px;">
            <div class="gallery-item">
                <img src="<?php echo htmlspecialchars(asset('images/businesslocation.gif'), ENT_QUOTES, 'UTF-8'); ?>" alt="Business Location">
            </div>
        </div>
    </section>
