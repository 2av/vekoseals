<?php $title = 'Polymers Details - Vako Seals Pvt. Ltd.'; ?>
<?php $description = 'Polymers Details - Comprehensive information about polymers used in Vako Seals products'; ?>

<section class="hero">
        <h1>Polymers Details</h1>
        <p>Comprehensive information about the polymers we use in our products</p>
    </section>

    <section class="content-section">
        <h2 id="ffkm">FFKM - Perfluoroelastomer</h2>
        <p>Perfluoroelastomer (FFKM) also commonly known as Kalrez®. This unique material which endures the harshest known environments can now be supplied by us in the form of moulded O-Rings as per Customer specification.</p>
        <p>FFKM has unbeatable resistance to concentrated acids, alkalis, steam, organic alcohols, ketones & esters. It has an attractive wide service temperature range from <strong>-25°C to 300°C</strong>. FFKM is also immune to sudden changes in service environments and lasts much longer than conventional elastomers including FPM (Viton®).</p>
        <p><em>Kalrez® and Viton® are registered trademarks of Du-pont Dow elastomers Inc.</em></p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="nbr">NBR - Acrylonitrile Butadiene Rubber</h2>
        <p>This polymer which is commonly referred to as Nitrile or Buna-N is a co-polymer of Butadiene and Acrylonitrile. They are differentiated based on the percentage of bound Acrylonitrile (ACN) content in the polymer.</p>
        <p>The low ACN polymers have good low temperature flexibility, compression set resistance and good elastic properties, but moderate resistance to oils and fuels. As the ACN content increases, resistance to mineral oils, fuels and greases increases, but properties such as low temperature flexibility, compression set resistance and elasticity deteriorate. Medium ACN polymers exhibit good balance of all the above properties. Normal service temperatures of these polymers range from <strong>-25°C to 120°C</strong>.</p>
        <h3>VAKO's NBR compounds are suitable for:</h3>
        <ul>
            <li>Compounds for low temperature applications as low as -45°C</li>
            <li>Compounds for high temperature applications up to 130°C</li>
            <li>Compounds with very low compression set</li>
            <li>Compounds for food applications</li>
            <li>Compounds for general purpose applications</li>
        </ul>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="cr">CR - Polychloroprene Rubber</h2>
        <p>This polymer is based on 2-chloro-1,3 butadiene and is commonly referred to as Neoprene. The chief characteristics of the polymer are flame retardancy, excellent ageing properties in ozone and weather environments along with resistance to abrasion and flex fatigue.</p>
        <p>Polychloroprene exhibits good resistance to mineral oils with high aniline point, greases, refrigerants and water.</p>
        <h3>VAKO's CR compounds include:</h3>
        <ul>
            <li>Compounds for high friction applications</li>
            <li>Compounds with excellent flex cracking resistance</li>
            <li>Compounds for general purpose applications</li>
        </ul>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="epdm">EPDM - Ethylene Propylene Terpolymers</h2>
        <p>This polymer is a terpolymer of ethylene, propylene and some Diene as the termonomer. Moulded parts and seals from EPDM have good resistance to:</p>
        <ul>
            <li>Ozone, ageing and weathering</li>
            <li>Water and steam</li>
            <li>Dilute acid, alkalies, ketones, alcohols and polar organic media</li>
            <li>Phosphate ester based hydraulic fluids</li>
        </ul>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="acm">ACM - Polyacrylic Rubber</h2>
        <p>This polymer is a co-polymer of Ethyl acrylate or Butyl acrylate and a small amount of monomer which facilitates vulcanization.</p>
        <p>ACM has excellent resistance to heat, hydrocarbon oils, mineral oils, oxidation and ozone, but poor resistance to water, steam, acids and alkalis. Normal service temperature of ACM is <strong>-25°C to 175°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="eam">EAM - Ethylene Acrylate Rubber</h2>
        <p>This terpolymer of Ethylene, Methyl acrylate and a cure site monomer is commonly referred to as Vamac®.</p>
        <p>This polymer has better heat resistance than ACM. Other Properties include good low temperature flexibility, good resistance to weathering, sunlight, oxygen, ozone and good flame resistance. It has good resistance to Paraffin based mineral oils, water and refrigerants. Normal service temperature of AEM is <strong>-40°C to 175°C</strong>.</p>
        <p><em>Vamac is the registered trademark of Dupont Dow elastomers Inc.</em></p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="vmq">VMQ - Silicone Rubber</h2>
        <p>These are high molecular weight poly organo siloxanes. VMQ has both Vinyl and Methyl substituent groups on the polymer chain, while PVMQ has an additional Phenyl substituent group on the polymer chain.</p>
        <p>These polymers have excellent cold flexibility as well as high thermal resistance. They have excellent di-electric properties and very good resistance to attack by oxygen, ozone and sunlight. They however have moderate resistance to mineral oils. The most admirable property of this polymer is it's very wide service temperature range i.e <strong>-65°C to 250°C</strong>.</p>
        <h3>VAKO's Silicone compounds include:</h3>
        <ul>
            <li>Compounds for very high temperature applications up to 300°C</li>
            <li>Compounds for very low temperature applications up to -120°C</li>
            <li>Compounds with very low compression set</li>
            <li>Transparent compounds</li>
            <li>Compounds with good oil resistance</li>
            <li>Compounds for medical applications</li>
            <li>Compounds for general applications</li>
        </ul>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="fvmq">FVMQ - Fluorosilicone Rubber</h2>
        <p>FVMQ has a similar polymer structure as that of VMQ and has an additional Fluoro substituent group on the polymer chain.</p>
        <p>These polymers have very good fuel, oil and solvent resistance in addition to the regular properties of silicones. They are used for special applications.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="fkm">FKM - Fluorocarbon Elastomer</h2>
        <p>These versatile range of polymers which are commonly referred to as Viton® are used for a vast range of sealing applications due to its resistance to a broad spectrum of chemical and oil media and a wide range of temperatures. The co-polymer types of FKM are co-polymers of Hexa fluoropropylene (HFP) and Vinylidine difluoride (VF2) (Fluorine content = 65-66%) While the terpolymers have Tetra fluoroethylene (TFE) as the Termonomer (Fluorine content = 67-71%). Some terpolymers have an additional cure site monomer which are used for very speciality applications.</p>
        <p>FKM's exhibit excellent resistance to mineral oils, fuels, steam, alcohols, alcohol containing fuels, aliphatic and aromatic hydrocarbons. Chemical and oil resistance improve as the fluorine content of these polymers increase. However the co-polymer types of FKM give the best compression set resistance. Normal service temperatures for FKM is <strong>-20°C to 250°C</strong>.</p>
        <h3>VAKO's FKM compounds are used for:</h3>
        <ul>
            <li>Compounds with very low compression set</li>
            <li>Compounds for high temperature (up to 275°C) dynamic sealing applications</li>
            <li>Compounds for low temperature applications (up to -35°C)</li>
            <li>Compounds for general purpose applications</li>
        </ul>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="tfep">TFE/P - Tetrafluoroethylene Propylene Co-polymers</h2>
        <p>This is a copolymer of Tetra fluoro ethylene and propylene. It shows much better resistance than FKM in high pH caustics, Brine solutions, amines engine oils, engine coolants, power steering fluids, corrosion inhibitors and gamma radiation.</p>
        <p>It also exhibits less sensitivity to changes in chemical environments. They have good electrical insulation properties. Normal service temperatures of this polymer is <strong>-10°C to 280°C</strong>.</p>
        <p>VAKO's TFE/P compounds go into various special applications which include automotive, oilfield, aerospace and industrial environments.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="csm">CSM - Chlorosulphonated Polyethylene</h2>
        <p>This polymer based on polyethylene has chlorine side groups and chloro sulphonated side groups on the main chain. It is commonly referred to as HYPALON®.</p>
        <p>Vulcanizates of this polymer have very good resistance to flame, heat, ozone and weathering. They also have good resistance to swelling in hot water, steam, acids, bases, ketones, polar organic media and oxidising media. Normal service temperatures of this polymer is <strong>-20°C to 150°C</strong>.</p>
        <p><em>Hypalon is a registered trademark of Du pont Dow elastomers Inc.</em></p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="eco">ECO - Epichlorohydrin Rubber</h2>
        <p>This is a co-polymer of Epichlorohydrin and Ethylene oxide.</p>
        <p>ECO vulcanisates have very low permeability to gases and good resistance to weathering and ozone. They exhibit good resistance to mineral oils, greases, vegetable oils, aliphatic hydrocarbons, petroleum and water. Normal service temperature of this polymer ranges from <strong>-40°C to 150°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="xnbr">X-NBR - Carboxylated Nitrile Rubber</h2>
        <p>These are terpolymers of butadiene, acrylonitrile and methacrylic acid. As these polymers have carboxylic acid side groups they are referred to as Carboxylated Nitrile rubber.</p>
        <p>Moulded products of XNBR have very high tensile strength, tear strength and above all improved abrasion resistance than NBR. Normal temperatures of these polymers range from <strong>-25°C to 120°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="hsn">HSN (HNBR) - Hydrogenated Nitrile Rubber</h2>
        <p>The elimination of double bonds from the polymer chain of NBR, either partially or completely by hydrogenation gives Hydrogenated Nitrile rubber.</p>
        <p>These polymers have much improved heat resistance than NBR (heat resistance depends on the degree of hydrogenation). HNBR has outstanding resistance to heat, ozone, weathering, mineral oils, crude oils with amines, fuels, greases, aliphatic hydrocarbons and industrial chemicals. HNBR has very good mechanical properties and excellent wear resistance. Normal service temperatures of these polymers are <strong>-30°C to 150°C</strong>.</p>
        <h3>VAKO's HNBR compounds include:</h3>
        <ul>
            <li>Compounds with very low compression set</li>
            <li>Compounds for low temperature applications (up to -40°C)</li>
            <li>Compounds for oil drilling applications</li>
        </ul>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="iir">IIR - Butyl Rubber</h2>
        <p>These polymers mainly consist of isobutylene with a small amount of isoprene. The IIR elastomers have low gas permeability and good resistance to ozone and weathering.</p>
        <p>They have good resistance to glycol based fluids, acids, bases and steam. The halogenated butyls (i.e CIIR & BIIR) exhibit lower gas permeability, better resistance to ozone, weathering chemicals and above all better heat resistance than IIR. The normal service temperatures of these polymers is <strong>-40°C to 145°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="sbr">SBR - Styrene Butadiene Rubber</h2>
        <p>This is a co polymer of Butadiene and Styrene. This general purpose polymer has good resistance to dilute organic and inorganic acids, water, alcohols and brake fluids. Normal service temperatures of this polymer is <strong>-40°C to 110°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="au">AU - Polyurethane Rubber</h2>
        <p>These are high molecular weight organic materials having large number of urethane (NH-C-OO) groups. The polyester polyurethanes are referred to as AU. These materials can be made from as low as 40 shore-A up to 80 shore-D, to match various customer specifications.</p>
        <h3>The general properties of these materials are:</h3>
        <ul>
            <li>High mechanical properties, excellent abrasion resistance and good flexibility</li>
            <li>Very good resistance to ozone and oxidation</li>
            <li>Good resistance to mineral oils, greases and aliphatic hydrocarbons</li>
        </ul>
        <p>Normal service temperatures of these polymers are <strong>-30°C to 80°C</strong>.</p>
        <p>VAKO specializes in processing cast polyurethane rubbers as well as millable gum polyurethanes.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="tpu">TPU - Thermoplastic Polyurethane</h2>
        <p>These variety of polyurethanes give the highest tensile strength in polyurethanes and are thermoplastic in nature. They bridge the gap between conventional elastomers and thermoplastics.</p>
        <p>The abrasion resistance of these materials are excellent and they have much better load bearing capacity than conventional elastomers. Components of TPU don't crack despite repeated bendings and have much better impact resistance than conventional thermoplastics. They have very good resistance to ageing, weathering, ozone, oxidation, water, mineral oils, motor fuels, hydraulic fluids and solvents. Normal service temperature of these materials are <strong>-15°C to 120°C</strong>.</p>
        <p>VAKO specialises in processing thermoplastic polyurethanes from 75 shore-A to 75 shore-D.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="ptfe">PTFE - Polytetrafloroethylene</h2>
        <p>This homopolymer of tetra fluoro ethylene is also commonly known as Teflon®. This non rubbery material has many outstanding properties. It's chemical resistance is superior to any other thermoplastic or elastomer and it has excellent resistance to swelling in almost all known media. This non toxic material has low co-efficient of friction and is non flammable. It's electrical insulation properties are also outstanding. Service temperature range is <strong>-270°C to 260°C</strong>.</p>
        <p>VAKO provides various PTFE moulded components, as well as PTFE filled with graphite, glass fibre, carbon and bronze moulded components as per the application.</p>
        <p><em>Teflon is a registered trademark of Du Pont.</em></p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="pom">POM - Polyoxymethylene (Polyacetal)</h2>
        <p>This thermoplastic material is also referred to as Poly acetal. This material due to it's good stiffness, hardness and strength has the ability to take very high loads. In certain applications it can replace metal parts like brass and aluminium. It also exhibits better dimensional stability than other thermoplastics in moist condition due to it's very low water absorption. Normal service temperatures of this material is <strong>-40°C to 140°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>

    <section class="content-section">
        <h2 id="ny">NYLON</h2>
        <p>This family of thermoplastics is widely used for anti-extrusion purposes and other sealing applications. Nylon is resistant to various petroleum and phosphate ester based hydraulic fluids. Normal service temperatures are <strong>-50°C to 120°C</strong>.</p>
        <p><a href="<?php echo htmlspecialchars(route('products'), ENT_QUOTES, 'UTF-8'); ?>" class="btn">Back to Products</a></p>
    </section>
